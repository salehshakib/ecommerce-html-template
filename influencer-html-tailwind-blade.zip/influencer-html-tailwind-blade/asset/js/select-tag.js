$(".js-example-tags").select2({
  tags: true,
});
