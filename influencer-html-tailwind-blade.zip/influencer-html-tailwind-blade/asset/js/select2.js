$(document).ready(function () {
  $("#country-select").select2({
    placeholder: "Select a country",
    allowClear: true,
  });
});
